import 'package:flutter/material.dart';

class others extends StatefulWidget {
  @override
  _othersState createState() => _othersState();
}

class _othersState extends State<others> {
  @override
  Widget build(BuildContext context) {
    bool _sellermode = false;
    return Scaffold(
      body: Text("aaas"),
    );
  }
}

